#include "CMachineState.h"

// === Constructor ===
CMachineState::CMachineState()
{
  m_isActive = true;

}
